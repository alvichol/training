from flask import Flask, render_template
app = Flask(__name__)


@app.route('/training/<prof>')
def training(prof):
    if 'инженер' in prof.lower() or 'строитель' in prof.lower():
        spec = 'engineer'
    else:
        spec = 'scientist'
    return render_template('training.html', spec=spec)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')

